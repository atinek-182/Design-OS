# ZORIXEL Next.js 15 Starter Kit v1

Official Zorixel Starter Template with OKLCH Design Tokens and GSAP integration.
